### RESOURCES Folder
#### This folder is used to keep all the resources which we are using like images/videos.
