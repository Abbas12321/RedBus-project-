# RedBus-Project

#### Steps to install project and work on seperate branches
```
git clone git@github.com:<your SSH key>/github_guide.git
cd RedBus-Project
git branch
git branch <your Name>
git checkout <your Branch Name>

```
#### To work with JSON server
```
cd RedBus-Project
npm install
npm run start

```
