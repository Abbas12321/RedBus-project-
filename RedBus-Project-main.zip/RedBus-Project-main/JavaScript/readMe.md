### JAVASCRIPT Folder
#### This folder is used to keep all the js files.